# Reverse Tic-Tac-Toe

Reverse Tic-Tac-Toe is a competitive game where humans play against an AI opponent. The AI employs the Alpha-Beta Pruning algorithm, enabling it to make strategic moves and frequently outmatch human players. It effectively guides opponents into unfavorable positions while skillfully defending against potential threats.

## How to Run the Code

1. Open the zip file
2. **Compile**: `g++ ReverseTTTMain.cpp -o ReverseTTTMain -std=c++11`
3. **Run**: `./ReverseTTTMain`

## How To Play

1. Compile and run the code.
2. The board is displayed, and the user plays first as "X".
3. Enter a move (0-8) corresponding to an empty position.
4. The AI selects its move and updates the board.
5. Repeat until a win or a draw.

## Key Components

1. **GameState Class**: Represents the current game state, including the current player, utility value, a 3x3 grid (1D vector) for the board, and a list of valid moves.

2. **Game Class**: A template for turn-based games, with methods like `actions()`, `result()`, `utility()`, `terminal_test()`, and `display()`. The `ReverseTicTacToe` class implements this template.

3. **ReverseTicTacToe Class**: Implements the rules of Reverse Tic-Tac-Toe, returning valid moves, updating the board after a move, alternating turns, evaluating the winner, checking if the game is over, and displaying the board.

4. **Alpha-Beta Pruning Algorithm**: Optimizes AI decision-making by searching the game tree for the best move while pruning unnecessary branches.

5. **Main Function**: Initializes the game with an empty board, alternates between user and AI moves, displays the game state after each move, and announces the winner at the end.
