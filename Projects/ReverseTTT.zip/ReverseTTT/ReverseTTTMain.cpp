#include <iostream>
#include <vector>
#include <limits>
#include <random>
#include <functional>
#include <memory>
#include <algorithm>
#include <set>

using namespace std;

// GameState Class
class GameState {
public:
    string to_move;
    int utility;
    vector<string> board;
    vector<string> moves;

    GameState(string to_move, int utility, vector<string> board, vector<string> moves)
        : to_move(to_move), utility(utility), board(board), moves(moves) {}
};

// Abstract Game Class
class Game {
public:
    virtual vector<string> actions(const GameState& state) = 0;
    virtual GameState result(const GameState& state, const string& move) = 0;
    virtual int utility(const GameState& state, const string& player) = 0;
    virtual bool terminal_test(const GameState& state) = 0;
    virtual string to_move(const GameState& state) = 0;
    virtual void display(const GameState& state) = 0;
    virtual ~Game() {}
};

// Alpha-Beta Pruning Function
string alpha_beta_pruning(const GameState& state, Game& game) {
    string player = game.to_move(state);

    function<int(const GameState&, int, int)> max_value;
    function<int(const GameState&, int, int)> min_value;

    // Maximize for the current player (Player 'X')
    max_value = [&](const GameState& state, int alpha, int beta) -> int {
        if (game.terminal_test(state)) {
            return game.utility(state, player);
        }
        int v = numeric_limits<int>::min();
        for (const auto& action : game.actions(state)) {
            // Apply the move and evaluate the result using min_value
            v = max(v, min_value(game.result(state, action), alpha, beta));
            if (v >= beta) return v;  // Beta cut-off
            alpha = max(alpha, v);    // Update alpha (maximize)
        }
        return v;
    };

    // Minimize for the opponent (Player 'O')
    min_value = [&](const GameState& state, int alpha, int beta) -> int {
        if (game.terminal_test(state)) {
            return game.utility(state, player);
        }
        int v = numeric_limits<int>::max();
        for (const auto& action : game.actions(state)) {
            // Apply the move and evaluate the result using max_value
            v = min(v, max_value(game.result(state, action), alpha, beta));
            if (v <= alpha) return v;  // Alpha cut-off
            beta = min(beta, v);       // Update beta (minimize)
        }
        return v;
    };

    // Initial values for the alpha-beta pruning
    int best_value = numeric_limits<int>::min();
    int beta = numeric_limits<int>::max();
    string best_action;

    // Loop through all possible actions and choose the best move
    for (const auto& action : game.actions(state)) {
        // Try the action and evaluate the result using min_value
        int v = min_value(game.result(state, action), best_value, beta);
        if (v > best_value) {
            best_value = v;
            best_action = action;
        }
    }
    return best_action;
}

// Get Adjacent Indicies Function
vector<int> get_adjacent_indices(int index) {
    vector<int> adj;
    // The Tic-Tac-Toe board has 9 positions, with indexes from 0 to 8
    int row = index / 3;
    int col = index % 3;

    // Possible directions: up, down, left, right, and diagonals
    vector<pair<int, int>> directions = {
        {-1, 0}, {1, 0}, {0, -1}, {0, 1},  // up, down, left, right
        {-1, -1}, {-1, 1}, {1, -1}, {1, 1}  // diagonals
    };

    for (const auto& dir : directions) {
        int new_row = row + dir.first;
        int new_col = col + dir.second;
        if (new_row >= 0 && new_row < 3 && new_col >= 0 && new_col < 3) {
            adj.push_back(new_row * 3 + new_col);  // Convert (row, col) to index
        }
    }

    return adj;
}

// Example Game Implementation: Reverse Tic-Tac-Toe
class ReverseTicTacToe : public Game {
public:
    vector<string> actions(const GameState& state) override {
        vector<string> valid_actions;
        for (int i = 0; i < 9; ++i) {
            if (state.board[i] == " ") {
                valid_actions.push_back(to_string(i));
            }
        }
        return valid_actions;
    }

    GameState result(const GameState& state, const string& move) override {
        vector<string> new_board = state.board;
        int index = stoi(move);
        new_board[index] = state.to_move;
        return GameState(state.to_move == "X" ? "O" : "X", 0, new_board, {});
    }

    int utility(const GameState& state, const string& player) override {
        const vector<vector<int>> win_positions = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8},  // rows
            {0, 3, 6}, {1, 4, 7}, {2, 5, 8},  // columns
            {0, 4, 8}, {2, 4, 6}              // diagonals
        };

        for (const auto& pos : win_positions) {
            if (state.board[pos[0]] == state.board[pos[1]] &&
                state.board[pos[1]] == state.board[pos[2]] &&
                state.board[pos[0]] != " ") {
                return state.board[pos[0]] == player ? -1 : 1;
            }
        }

        return 0;  // Ongoing game or draw
    }

    bool terminal_test(const GameState& state) override {
        // Check if game has ended (board is full or there is a winner)
        return find(state.board.begin(), state.board.end(), " ") == state.board.end() || 
               utility(state, "X") != 0 || utility(state, "O") != 0;
    }

    string to_move(const GameState& state) override {
        return state.to_move;
    }

    void display(const GameState& state) override {
        cout << "-------------\n";
        for (int i = 0; i < 9; ++i) {
            cout << "| " << state.board[i] << " ";
            if ((i + 1) % 3 == 0) {
                cout << "|\n";
                if (i != 8) cout << "-------------\n";
            }
        }
        cout << "-------------\n";
    }
};

int main() {
    ReverseTicTacToe game;
    GameState initial_state("X", 0, vector<string>(9, " "), {});
    string user_player = "X";  // User will play as "X"
    string ai_player = "O";    // AI will play as "O"

    game.display(initial_state);

    while (!game.terminal_test(initial_state)) {
        if (initial_state.to_move == user_player) {
            // User's turn
            vector<string> moves = game.actions(initial_state);
            if (moves.empty()) break;

            cout << "Your turn. Available moves: ";
            for (const auto& move : moves) cout << move << " ";
            cout << "\nChoose your move: ";

            string move;
            cin >> move;

            // Validate the user's move
            while (find(moves.begin(), moves.end(), move) == moves.end()) {
                cout << "Invalid move. Try again: ";
                cin >> move;
            }

            initial_state = game.result(initial_state, move);
        } else {
            // AI's turn
            cout << "AI is thinking...\n";
            string move = alpha_beta_pruning(initial_state, game);
            cout << "AI chose move: " << move << endl;
            initial_state = game.result(initial_state, move);
        }

        game.display(initial_state);
    }

    // Display the result of the game
    int result = game.utility(initial_state, user_player);
    if (result == 1) {
        cout << "Congratulations! You won!\n";
    } else if (result == -1) {
        cout << "AI won! Better luck next time.\n";
    } else {
        cout << "It's a draw!\n";
    }

    cout << "Game Over!" << endl;
    return 0;
}
